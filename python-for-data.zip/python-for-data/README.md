# python-for-data
Set of notebooks that contain basic Python concepts, suitable for Data-related roles that want to use Python.

### References
- These notebooks are referenced from [Kaggle](https://www.kaggle.com/learn/python), with little modifications 
